package com.example.felipesantos.classesemetodos;

class Casa {
    String cor;

    void abrirPorta(){
        System.out.println("Porta aberta");
    }
}
